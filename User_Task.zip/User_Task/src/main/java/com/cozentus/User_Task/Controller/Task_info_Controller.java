package com.cozentus.User_Task.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.User_Task.DTO.TaskAssignmentDTO;
import com.cozentus.User_Task.Modal.Task_Assigment;
import com.cozentus.User_Task.Modal.Task_Info;
import com.cozentus.User_Task.Repository.Task_AssignedRepository;
import com.cozentus.User_Task.Services.Task_Info_Service;

@RestController
@CrossOrigin(origins = "*",allowedHeaders ="*") 
@RequestMapping("/task")
public class Task_info_Controller {
	
	@Autowired
	private Task_Info_Service taskInfoService;
	
	@Autowired
	private Task_AssignedRepository  taskAssignedRepo;
	
	 @GetMapping("/show/all")
	    public List<Task_Info> getAllTasks() {
	        return taskInfoService.getAllTasks();
	    }

	    @GetMapping("/show/{taskId}")
	    public ResponseEntity<Task_Info> getTaskById(@PathVariable Integer taskId) {
	        Optional<Task_Info> task = taskInfoService.getTaskById(taskId);
	        if (task.isPresent()) {
	            return ResponseEntity.ok(task.get());
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	    @PostMapping("/addTask/{userId}")
	    public ResponseEntity<Task_Info> createTask(@RequestBody Task_Info task, @PathVariable Integer userId) {
	        Task_Info newTask = taskInfoService.createTask(task);

	        Task_Assigment taskAssignment = new Task_Assigment();
	        taskAssignment.setTaskId(newTask.getTaskId());
	        taskAssignment.setUserId(userId);

	        taskAssignedRepo.save(taskAssignment);

	        return ResponseEntity.ok(newTask);
	    }


	    @PostMapping("/update/{taskId}")
	    public ResponseEntity<Task_Info> updateTask(@PathVariable Integer taskId, @RequestBody Task_Info task) {
	        Task_Info updatedTask = taskInfoService.updateTask(taskId, task);
	        if (updatedTask != null) {
	            return ResponseEntity.ok(updatedTask);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	    @PostMapping("/delete/{taskId}")
	    public ResponseEntity<Void> deleteTask(@PathVariable Integer taskId) {
	        taskInfoService.deleteTask(taskId);
	        return ResponseEntity.noContent().build();
	    }
	    
	    
	  
}
