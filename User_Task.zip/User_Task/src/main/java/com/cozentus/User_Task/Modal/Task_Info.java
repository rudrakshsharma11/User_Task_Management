package com.cozentus.User_Task.Modal;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "task")
public class Task_Info {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TaskID")
	private Integer TaskId;
	
	@Column(name="Title")
	private String title;
	
	@Column(name="Description")
	private String description;
	
	@Column(name="Priority")
	private Integer priority;
	
	@Column(name = "Deadline")
	private Date deadline;
	
	@Column(name="Status")
	private String status;

	public Task_Info() {
		
	}

	public Task_Info(Integer taskId, String title, String description, Integer priority, Date deadline, String status) {
		super();
		TaskId = taskId;
		this.title = title;
		this.description = description;
		this.priority = priority;
		this.deadline = deadline;
		this.status = status;
	}

	public Integer getTaskId() {
		return TaskId;
	}

	public void setTaskId(Integer taskId) {
		TaskId = taskId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Date getDeadline() {
		return deadline;
	}

	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Task_Info [TaskId=" + TaskId + ", title=" + title + ", description=" + description + ", priority="
				+ priority + ", deadline=" + deadline + ", status=" + status + "]";
	}
	
	
	

}
