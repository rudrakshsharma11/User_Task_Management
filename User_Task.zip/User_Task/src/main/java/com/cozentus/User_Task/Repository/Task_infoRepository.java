package com.cozentus.User_Task.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cozentus.User_Task.Modal.Task_Info;

public interface Task_infoRepository extends JpaRepository<Task_Info, Integer> {

}
