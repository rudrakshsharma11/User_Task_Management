package com.cozentus.User_Task.DTO;

import com.cozentus.User_Task.Modal.Task_Info;
import com.cozentus.User_Task.Modal.User_info;

public class TaskAssignmentDTO {
	 private User_info user;
	   private Task_Info task;
	   
	public TaskAssignmentDTO(User_info user, Task_Info task) {
		super();
		this.user = user;
		this.task = task;
	}

	public TaskAssignmentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User_info getUser() {
		return user;
	}

	public void setUser(User_info user) {
		this.user = user;
	}

	public Task_Info getTask() {
		return task;
	}

	public void setTask(Task_Info task) {
		this.task = task;
	}

	@Override
	public String toString() {
		return "TaskAssignmentDTO [user=" + user + ", task=" + task + "]";
	}
	
	
	   
	   

}
