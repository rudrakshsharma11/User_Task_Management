package com.cozentus.User_Task.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cozentus.User_Task.Modal.User_info;

public interface User_infoRepository extends JpaRepository<User_info,Integer> {
	
	 User_info findUserByUserEmailAndPassword(String userEmail, String password);

}
