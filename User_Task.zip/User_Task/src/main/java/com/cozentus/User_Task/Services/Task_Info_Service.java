package com.cozentus.User_Task.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.User_Task.DTO.TaskAssignmentDTO;
import com.cozentus.User_Task.Modal.Task_Info;
import com.cozentus.User_Task.Modal.User_info;
import com.cozentus.User_Task.Repository.Task_infoRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class Task_Info_Service {
	
	@Autowired
	private Task_infoRepository taskInfoRepository;
	
	 @PersistenceContext
	private EntityManager entityManager;
	
	
	 public List<Task_Info> getAllTasks() {
	        return taskInfoRepository.findAll();
	    }

	    public Optional<Task_Info> getTaskById(Integer taskId) {
	        return taskInfoRepository.findById(taskId);
	    }

	    public Task_Info createTask(Task_Info task) {
	        return taskInfoRepository.save(task);
	    }

	    public Task_Info updateTask(Integer taskId, Task_Info task) {
	        if (taskInfoRepository.existsById(taskId)) {
	            task.setTaskId(taskId);
	            return taskInfoRepository.save(task);
	        } else {
	            // Handle the case where the task does not exist
	            return null;
	        }
	    }

	    public void deleteTask(Integer taskId) {
	        taskInfoRepository.deleteById(taskId);
	    }
	    
	  
}
