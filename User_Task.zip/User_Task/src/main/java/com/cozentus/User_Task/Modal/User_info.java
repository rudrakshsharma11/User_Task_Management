package com.cozentus.User_Task.Modal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_info")
public class User_info {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserID")
	private Integer userId;
	
	@Column(name="Name")
	private String name;
	
	@Column(name = "Email")
	private String userEmail;
	
	@Column(name = "Password")
	private String password;
	
	@Column(name = "ProfilePicture")
	private String profile_Picture;

	public User_info() {
		
	}

	public User_info(Integer userId, String name, String userEmail, String password, String profile_Picture) {
		super();
		this.userId = userId;
		this.name = name;
		this.userEmail = userEmail;
		this.password = password;
		this.profile_Picture = profile_Picture;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfile_Picture() {
		return profile_Picture;
	}

	public void setProfile_Picture(String profile_Picture) {
		this.profile_Picture = profile_Picture;
	}

	@Override
	public String toString() {
		return "User_info [userId=" + userId + ", name=" + name + ", userEmail=" + userEmail + ", password=" + password
				+ ", profile_Picture=" + profile_Picture + "]";
	}


	
	
	
	
	
	

}
