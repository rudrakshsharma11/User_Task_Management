package com.cozentus.User_Task.Controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.User_Task.Modal.User_info;
import com.cozentus.User_Task.Services.User_info_Service;

@RestController
@CrossOrigin(origins = "*",allowedHeaders ="*") 
@RequestMapping("/users")
public class User_info_Controller {
	
	@Autowired
    private User_info_Service userInfoService;
	
	 @GetMapping("/show/all")
    public List<User_info> getAllUsers() {
        return userInfoService.getAllUsers();
    }

    @GetMapping("/show/{userId}")
    public ResponseEntity<User_info> getUserById(@PathVariable Integer userId) {
        Optional<User_info> user = userInfoService.getUserById(userId);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            // Handle the case where the user does not exist
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/addUser")
    public ResponseEntity<User_info> createUser(@RequestBody User_info user) {
        User_info newUser = userInfoService.createUser(user);
        return ResponseEntity.ok(newUser);
    }

    @PostMapping("/update/{userId}")
    public ResponseEntity<User_info> updateUser(@PathVariable Integer userId, @RequestBody User_info user) {
        User_info updatedUser = userInfoService.updateUser(userId, user);
        if (updatedUser != null) {
            return ResponseEntity.ok(updatedUser);
        } else {
            // Handle the case where the user does not exist
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/delete/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Integer userId) {
    	userInfoService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }
    
    
    
    @PostMapping("/authenticate")
    public ResponseEntity<User_info> authenticateUser(@RequestBody Map<String, String> requestBody) {
        String userEmail = requestBody.get("userEmail");
        String password = requestBody.get("password");
        User_info user = userInfoService.findUserByUserEmailAndPassword(userEmail, password);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            // Handle the case where authentication fails (e.g., return an error response)
            return ResponseEntity.notFound().build();
        }
    }
	
	

}
