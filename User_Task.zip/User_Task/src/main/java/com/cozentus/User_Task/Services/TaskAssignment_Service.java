package com.cozentus.User_Task.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.User_Task.DTO.TaskAssignmentDTO;
import com.cozentus.User_Task.Modal.Task_Info;
import com.cozentus.User_Task.Modal.User_info;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Service
public class TaskAssignment_Service {
	 @Autowired
	   private EntityManager entityManager;
	 
	 public List<TaskAssignmentDTO> getTaskAssignmentsWithUserData() {
		 String sql = "SELECT u.*, t.* " +
	             "FROM task_assignment ta " +
	             "INNER JOIN user_info u ON ta.userid = u.userId " +
	             "INNER JOIN task t ON ta.taskid = t.TaskId";


	        Query query = entityManager.createNativeQuery(sql);

	        List<Object[]> resultList = query.getResultList();
	        List<TaskAssignmentDTO> taskAssignments = new ArrayList<>();

	        for (Object[] row : resultList) {
	            User_info user = (User_info) row[1];
	            Task_Info task = (Task_Info) row[2];
	            taskAssignments.add(new TaskAssignmentDTO(user, task));
	        }

	        return taskAssignments;
	    }

}
