package com.cozentus.User_Task.Modal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "task_assignment")
public class Task_Assigment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "task_assigned_id")
	private Integer task_assigment_Id;
	
	@Column(name = "taskid")
	private Integer taskId;
	
	@Column(name = "userid")
	private Integer userId;

	public Task_Assigment() {
		
	}

	public Task_Assigment(Integer task_assigment_Id, Integer taskId, Integer userId) {
		super();
		this.task_assigment_Id = task_assigment_Id;
		this.taskId = taskId;
		this.userId = userId;
	}

	public Integer getTask_assigment_Id() {
		return task_assigment_Id;
	}

	public void setTask_assigment_Id(Integer task_assigment_Id) {
		this.task_assigment_Id = task_assigment_Id;
	}

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Task_Assigment [task_assigment_Id=" + task_assigment_Id + ", taskId=" + taskId + ", userId=" + userId
				+ "]";
	}
	
	
	

}
