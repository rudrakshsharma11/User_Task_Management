package com.cozentus.User_Task.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.User_Task.Modal.User_info;
import com.cozentus.User_Task.Repository.User_infoRepository;

@Service
public class User_info_Service {
	
	 @Autowired
	    private User_infoRepository userRepository;
	 
	 
	 public List<User_info> getAllUsers() {
	        return userRepository.findAll();
	    }

	    public Optional<User_info> getUserById(Integer userId) {
	        return userRepository.findById(userId);
	    }

	    public User_info createUser(User_info user) {
	        return userRepository.save(user);
	    }

	    public User_info updateUser(Integer userId, User_info user) {
	        if (userRepository.existsById(userId)) {
	            user.setUserId(userId);
	            return userRepository.save(user);
	        } else {
	            // Handle the case where the user does not exist
	            return null;
	        }
	    }

	    public void deleteUser(Integer userId) {
	        userRepository.deleteById(userId);
	    }
	    
	    
	    
	    public User_info findUserByUserEmailAndPassword(String userEmail, String password) {
	        return userRepository.findUserByUserEmailAndPassword(userEmail, password);
	    }

}
