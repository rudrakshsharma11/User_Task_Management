package com.cozentus.User_Task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
